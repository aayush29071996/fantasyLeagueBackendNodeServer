module.exports = {
  'googleAuth':{
    'clientID' : '486986714295-j39jdglq21v4313u04tk96s3d3rad1c2.apps.googleusercontent.com',
    'clientSecret' : '-SChCQwvtNrwcJKWwkmavEqi',
    'callbackURL' : 'https://inyards.herokuapp.com'
  },
}
