/*
 * Created by harirudhra on Sat 11 March 2017
 */

var FixtureJob = require('./jobs/Football/FixtureJob');
	

module.exports = function(app) {
	  FixtureJob.updateFixturesJob();
	  FixtureJob.calculatePointsJob();
}